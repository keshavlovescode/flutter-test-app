import 'package:flutter/material.dart';

class AnalyticsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Left Side: Sidebar
          Container(
            width: 200,
            color: Color(0xFF2C2F5B), // Dark purple color
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Logo at the top
                Padding(
                  padding: const EdgeInsets.only(top: 24.0),
                  child: Image.asset(
                    'assets/wijungle_logo.png', // Replace with your logo
                    height: 60,
                  ),
                ),
                // Navigation
                Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.analytics, color: Colors.white),
                      title: Text('Analytics',
                          style: TextStyle(color: Colors.white)),
                    ),
                    ListTile(
                      leading: Icon(Icons.feedback, color: Colors.white),
                      title: Text('Feedback',
                          style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
                SizedBox(height: 32.0),
              ],
            ),
          ),
          // Right Side: Content Area
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Analytics',
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.bold)),
                      Row(
                        children: [
                          Text('Hello User', style: TextStyle(fontSize: 16)),
                          SizedBox(width: 8.0),
                          CircleAvatar(
                            backgroundImage: AssetImage(
                                'assets/user.png'), // Replace with user image
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(height: 24.0),
                  // Circular Progress Indicators
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CircularIndicator(label: 'CPU', percentage: 76),
                      CircularIndicator(label: 'RAM', percentage: 76),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CircularIndicator extends StatelessWidget {
  final String label;
  final int percentage;

  CircularIndicator({required this.label, required this.percentage});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 120,
              height: 120,
              child: CircularProgressIndicator(
                value: percentage / 100,
                strokeWidth: 12,
                backgroundColor: Colors.grey.shade300,
                color: Colors.blue,
              ),
            ),
            Text('$percentage%',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ],
        ),
        SizedBox(height: 8.0),
        Text(label, style: TextStyle(fontSize: 16)),
      ],
    );
  }
}
