import 'package:flutter/material.dart';
import 'login_page.dart';
import 'analytics_page.dart';

void main() {
  runApp(WiJungleApp());
}

class WiJungleApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => LoginPage(),
        '/analytics': (context) => AnalyticsPage(),
      },
    );
  }
}
